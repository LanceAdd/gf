// Copyright GoFrame Author(https://goframe.org). All Rights Reserved.
//
// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file,
// You can obtain one at https://github.com/gogf/gf.

package common

import (
	"context"
	"os"
	"sync"
	"testing"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/os/gctx"

	seataMysql "github.com/gogf/gf/contrib/drivers/seata_mysql"
)

var (
	// seataInitOnce 确保 Seata 只初始化一次
	seataInitOnce sync.Once
	// seataInitErr 保存初始化错误
	seataInitErr error
)

// SetupSeataDB 初始化 Seata 数据库连接（AT 模式）
func SetupSeataDB(t *testing.T, mode string) gdb.DB {
	ctx := gctx.GetInitCtx()

	// 使用 sync.Once 确保 Seata 只初始化一次
	seataInitOnce.Do(func() {
		// 设置 Seata 配置文件路径
		os.Setenv("SEATA_GO_CONFIG_PATH", "./setup/seata.yml")

		// 初始化 Seata Driver
		config := &seataMysql.Config{
			Enabled:        true,
			ApplicationID:  "gf-seata-test",
			TxServiceGroup: "default_tx_group",
			Mode:           mode,
			AT: seataMysql.ATConfig{
				UndoLogTable: "undo_log",
			},
		}

		seataInitErr = seataMysql.Init(config)
	})

	// 检查初始化是否成功
	if seataInitErr != nil {
		t.Fatalf("❌ Seata 初始化失败: %v", seataInitErr)
	}

	t.Logf("✅ Seata %s 模式已初始化", mode)

	// 创建数据库实例
	node := gdb.ConfigNode{
		Type:    seataMysql.DriverNameATMySQL,
		Host:    "127.0.0.1",
		Port:    "3306",
		User:    "root",
		Pass:    "123456",
		Name:    "seata_test",
		Charset: "utf8mb4",
		Extra:   "parseTime=true",
	}

	db, err := gdb.New(node)
	if err != nil {
		t.Fatalf("❌ 创建数据库实例失败: %v", err)
	}

	// 测试连接
	err = db.PingMaster()
	if err != nil {
		t.Fatalf("❌ 数据库连接失败: %v", err)
	}

	_ = ctx // 避免 unused 警告
	return db
}

// ResetAccountBalances 重置账户余额到初始状态（使用链式调用）
func ResetAccountBalances(ctx context.Context, db gdb.DB) error {
	// 使用链式调用重置账户1
	_, err := db.Model("accounts").Ctx(ctx).Where("user_id", 1).Data(gdb.Map{
		"balance": 10000.00,
	}).Update()
	if err != nil {
		return err
	}

	// 使用链式调用重置账户2
	_, err = db.Model("accounts").Ctx(ctx).Where("user_id", 2).Data(gdb.Map{
		"balance": 5000.00,
	}).Update()
	if err != nil {
		return err
	}

	// 重置账户3（用于并发测试）
	_, err = db.Model("accounts").Ctx(ctx).Where("user_id", 3).Data(gdb.Map{
		"balance": 2000.00,
	}).Update()
	return err
}

// ResetProductStock 重置产品库存到初始状态（使用链式调用）
func ResetProductStock(ctx context.Context, db gdb.DB) error {
	products := []struct {
		id    int
		stock int
	}{
		{1, 100},
		{2, 50},
		{3, 200},
		{4, 80},
		{5, 150},
	}

	for _, product := range products {
		_, err := db.Model("products").Ctx(ctx).Where("id", product.id).Data(gdb.Map{
			"stock": product.stock,
		}).Update()
		if err != nil {
			return err
		}
	}

	return nil
}

// GetAccountBalance 获取账户余额
func GetAccountBalance(ctx context.Context, db gdb.DB, userID int) (float64, error) {
	type Account struct {
		Balance float64
	}
	var account Account
	err := db.Model("accounts").Where("user_id", userID).Scan(&account)
	if err != nil {
		return 0, err
	}
	return account.Balance, nil
}

// GetProductStock 获取产品库存
func GetProductStock(ctx context.Context, db gdb.DB, productID int) (int, error) {
	type Product struct {
		Stock int
	}
	var product Product
	err := db.Model("products").Where("id", productID).Scan(&product)
	if err != nil {
		return 0, err
	}
	return product.Stock, nil
}

// GetProductPrice 获取产品价格
func GetProductPrice(ctx context.Context, db gdb.DB, productID int) (float64, error) {
	type Product struct {
		Price float64
	}
	var product Product
	err := db.Model("products").Where("id", productID).Scan(&product)
	if err != nil {
		return 0, err
	}
	return product.Price, nil
}

// CleanupTestData 清理测试数据
func CleanupTestData(ctx context.Context, db gdb.DB) error {
	// 清理测试订单
	_, err := db.Model("orders").Ctx(ctx).Where("user_id > 3").Delete()
	if err != nil {
		return err
	}

	// 清理测试订单项
	_, err = db.Model("order_items").Ctx(ctx).Delete()
	if err != nil {
		return err
	}

	// 清理 undo_log（用于下一个测试）
	_, err = db.Model("undo_log").Ctx(ctx).Delete()
	return err
}

// WaitAndCheckUndoLog 等待并检查 undo_log 表
func WaitAndCheckUndoLog(ctx context.Context, db gdb.DB) (int64, error) {
	var count int64
	err := db.Model("undo_log").Ctx(ctx).Count(&count)
	if err != nil {
		return 0, err
	}
	return count, nil
}

// CreateTestOrder 创建测试订单
func CreateTestOrder(ctx context.Context, db gdb.DB, userID, productID int, quantity int, amount float64) (int64, error) {
	// 创建订单
	result, err := db.Model("orders").Ctx(ctx).Insert(gdb.Map{
		"user_id": userID,
		"product_id": productID,
		"amount": amount,
		"status": "PENDING",
	})
	if err != nil {
		return 0, err
	}

	orderID, err := result.LastInsertId()
	if err != nil {
		return 0, err
	}

	// 创建订单项
	_, err = db.Model("order_items").Ctx(ctx).Insert(gdb.Map{
		"order_id": orderID,
		"product_id": productID,
		"quantity": quantity,
		"price": amount / float64(quantity),
	})
	if err != nil {
		return 0, err
	}

	return orderID, nil
}

// ValidateOrder 验证订单是否创建成功
func ValidateOrder(ctx context.Context, db gdb.DB, orderID int64) (bool, error) {
	var count int
	err := db.Model("orders").Where("id", orderID).Count(&count)
	if err != nil {
		return false, err
	}
	return count > 0, nil
}

// ValidateBalance 验证账户余额
func ValidateBalance(ctx context.Context, db gdb.DB, userID int, expectedBalance float64) (bool, error) {
	balance, err := GetAccountBalance(ctx, db, userID)
	if err != nil {
		return false, err
	}
	return balance == expectedBalance, nil
}

// ValidateStock 验证产品库存
func ValidateStock(ctx context.Context, db gdb.DB, productID int, expectedStock int) (bool, error) {
	stock, err := GetProductStock(ctx, db, productID)
	if err != nil {
		return false, err
	}
	return stock == expectedStock, nil
}