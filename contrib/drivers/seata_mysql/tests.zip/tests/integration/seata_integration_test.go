// Copyright GoFrame Author(https://goframe.org). All Rights Reserved.
//
// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file,
// You can obtain one at https://github.com/goframe.org.

package integration

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame"
	"github.com/gogf/gf/v2/os/gctx"
	"github.com/gogf/gf/v2/test/gtest"
	"github.com/seata/seata-go/pkg/tm"

	seataMysql "github.com/gogf/gf/contrib/drivers/seata_mysql"
	"github.com/gogf/gf/contrib/drivers/seata_mysql/tests/common"
)

// TestIntegration_BasicConnectivity 测试基本数据库连接
func TestIntegration_BasicConnectivity(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test in short mode")
	}

	gtest.C(t, func(t *gtest.T) {
		config := gdb.ConfigNode{
			Type:     "mysql",
			Host:     "127.0.0.1",
			Port:     "3306",
			User:     "root",
			Pass:     "123456",
			Name:     "seata_test",
			Role:     "master",
			Charset:  "utf8mb4",
			Protocol: "tcp",
			Timezone: "UTC",
		}

		db, err := gdb.NewByConfig(config)
		t.AssertNil(err)
		t.AssertNE(db, nil)
		defer db.Close()

		ctx := gctx.New()
		_, err = db.Ping(ctx)
		t.AssertNil(err)
	})
}

// TestSeataAT_BasicTransfer AT模式基础转账测试
func TestSeataAT_BasicTransfer(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test in short mode")
	}

	gtest.C(t, func(t *gtest.T) {
		ctx := context.Background()
		db := common.SetupSeataDB(t.T, "AT")

		err := common.ResetAccountBalances(ctx, db)
		if err != nil {
			t.Fatalf("重置账户余额失败: %v", err)
		}

		balance1Before, err := common.GetAccountBalance(ctx, db, 1)
		t.AssertNil(err)
		t.AssertEQ(balance1Before, 10000.00)

		balance2Before, err := common.GetAccountBalance(ctx, db, 2)
		t.AssertNil(err)
		t.AssertEQ(balance2Before, 5000.00)

		t.Logf("转账前余额: 用户1=%.2f, 用户2=%.2f", balance1Before, balance2Before)

		err = tm.WithGlobalTx(ctx, &tm.GtxConfig{
			Name:    "basic-transfer",
			Timeout: 30 * time.Second,
		}, func(ctx context.Context) error {
			// 扣款
			_, err := db.Model("accounts").
				Where("id", 1).
				Data(gdb.Map{
					"balance": gdb.Raw("balance - ?", 500.00),
				}).Update()
			if err != nil {
				return err
			}

			// 加款
			_, err = db.Model("accounts").
				Where("id", 2).
				Data(gdb.Map{
					"balance": gdb.Raw("balance + ?", 500.00),
				}).Update()
			return err
		})

		t.AssertNil(err)

		balance1After, _ := common.GetAccountBalance(ctx, db, 1)
		balance2After, _ := common.GetAccountBalance(ctx, db, 2)

		t.AssertEQ(balance1After, 9500.00)
		t.AssertEQ(balance2After, 5500.00)

		t.Logf("转账后余额: 用户1=%.2f, 用户2=%.2f", balance1After, balance2After)
	})
}

// TestSeataAT_ConcurrentTransfer 并发转账测试
func TestSeataAT_ConcurrentTransfer(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test in short mode")
	}

	gtest.C(t, func(t *gtest.T) {
		ctx := context.Background()
		db := common.SetupSeataDB(t.T, "AT")

		err := common.ResetAccountBalances(ctx, db)
		if err != nil {
			t.Fatalf("重置账户余额失败: %v", err)
		}

		concurrency := 5
		amount := 100.00
		var wg sync.WaitGroup
		var mu sync.Mutex
		var successCount int
		var errorCount int
		results := make(chan string, concurrency)

		startTime := time.Now()

		for i := 0; i < concurrency; i++ {
			wg.Add(1)
			go func(id int) {
				defer wg.Done()

				err := tm.WithGlobalTx(ctx, &tm.GtxConfig{
					Name:    fmt.Sprintf("concurrent-transfer-%d", id),
					Timeout: 30 * time.Second,
				}, func(ctx context.Context) error {
					// 扣款
					_, err := db.Model("accounts").
						Where("id", 1).
						Data(gdb.Map{
							"balance": gdb.Raw("balance - ?", amount),
						}).Update()
					if err != nil {
						return err
					}

					// 加款
					_, err = db.Model("accounts").
						Where("id", 2).
						Data(gdb.Map{
							"balance": gdb.Raw("balance + ?", amount),
						}).Update()
					return err
				})

				mu.Lock()
				if err != nil {
					errorCount++
					results <- fmt.Sprintf("并发%d失败: %v", id, err)
				} else {
					successCount++
					results <- fmt.Sprintf("并发%d成功", id)
				}
				mu.Unlock()
			}(i)
		}

		wg.Wait()
		close(results)

		duration := time.Since(startTime)
		t.Logf("并发转账完成: 成功=%d, 失败=%d, 耗时=%v", successCount, errorCount, duration)

		for result := range results {
			t.Logf("  %s", result)
		}

		t.AssertEQ(successCount, concurrency)
		t.AssertEQ(errorCount, 0)

		balance1After, _ := common.GetAccountBalance(ctx, db, 1)
		balance2After, _ := common.GetAccountBalance(ctx, db, 2)

		t.AssertEQ(balance1After, 10000.00-amount*float64(concurrency))
		t.AssertEQ(balance2After, 5000.00+amount*float64(concurrency))
	})
}

// TestSeataAT_NestedTransactionBasic 基础嵌套事务测试
func TestSeataAT_NestedTransactionBasic(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test in short mode")
	}

	gtest.C(t, func(t *gtest.T) {
		ctx := context.Background()
		db := common.SetupSeataDB(t.T, "AT")

		err := common.ResetAccountBalances(ctx, db)
		if err != nil {
			t.Fatalf("重置账户余额失败: %v", err)
		}

		balance1Before, _ := common.GetAccountBalance(ctx, db, 1)
		balance2Before, _ := common.GetAccountBalance(ctx, db, 2)

		t.Logf("嵌套事务测试开始: 用户1=%.2f, 用户2=%.2f", balance1Before, balance2Before)

		err = tm.WithGlobalTx(ctx, &tm.GtxConfig{
			Name:    "outer-transaction",
			Timeout: 30 * time.Second,
		}, func(ctx context.Context) error {
			// 外层事务：转账100
			tx1, err := db.Begin(ctx)
			if err != nil {
				return err
			}
			defer tx1.Rollback()

			_, err = tx1.Model("accounts").
				Where("id", 1).
				Data(gdb.Map{"balance": gdb.Raw("balance - ?", 100)}).
				Update()
			if err != nil {
				return err
			}

			// 嵌套事务：转账50
			err = tm.WithGlobalTx(ctx, &tm.GtxConfig{
				Name:    "inner-transaction",
				Timeout: 30 * time.Second,
			}, func(ctx context.Context) error {
				tx2, err := db.Begin(ctx)
				if err != nil {
					return err
				}
				defer tx2.Rollback()

				_, err = tx2.Model("accounts").
					Where("id", 1).
					Data(gdb.Map{"balance": gdb.Raw("balance - ?", 50)}).
					Update()
				if err != nil {
					return err
				}

				_, err = tx2.Model("accounts").
					Where("id", 2).
					Data(gdb.Map{"balance": gdb.Raw("balance + ?", 50)}).
					Update()
				if err != nil {
					return err
				}

				return tx2.Commit()
			})
			if err != nil {
				return err
			}

			_, err = tx1.Model("accounts").
				Where("id", 2).
				Data(gdb.Map{"balance": gdb.Raw("balance + ?", 100)}).
				Update()
			if err != nil {
				return err
			}

			return tx1.Commit()
		})

		t.AssertNil(err)

		balance1After, _ := common.GetAccountBalance(ctx, db, 1)
		balance2After, _ := common.GetAccountBalance(ctx, db, 2)

		t.AssertEQ(balance1After, balance1Before-150.00)
		t.AssertEQ(balance2After, balance2Before+150.00)

		t.Logf("嵌套事务测试结束: 用户1=%.2f, 用户2=%.2f", balance1After, balance2After)
	})
}

// TestSeataAT_TransactionRollback 事务回滚测试
func TestSeataAT_TransactionRollback(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test in short mode")
	}

	gtest.C(t, func(t *gtest.T) {
		ctx := context.Background()
		db := common.SetupSeataDB(t.T, "AT")

		err := common.ResetAccountBalances(ctx, db)
		if err != nil {
			t.Fatalf("重置账户余额失败: %v", err)
		}

		balance1Before, _ := common.GetAccountBalance(ctx, db, 1)
		balance2Before, _ := common.GetAccountBalance(ctx, db, 2)

		t.Logf("回滚测试开始: 用户1=%.2f, 用户2=%.2f", balance1Before, balance2Before)

		err = tm.WithGlobalTx(ctx, &tm.GtxConfig{
			Name:    "rollback-test",
			Timeout: 30 * time.Second,
		}, func(ctx context.Context) error {
			// 扣款
			_, err := db.Model("accounts").
				Where("id", 1).
				Data(gdb.Map{
					"balance": gdb.Raw("balance - ?", 500.00),
				}).Update()
			if err != nil {
				return err
			}

			// 加款
			_, err = db.Model("accounts").
				Where("id", 2).
				Data(gdb.Map{
					"balance": gdb.Raw("balance + ?", 500.00),
				}).Update()
			if err != nil {
				return err
			}

			// 故意触发错误进行回滚
			return errors.New("intentional rollback error")
		})

		t.AssertNE(err, nil)

		balance1After, _ := common.GetAccountBalance(ctx, db, 1)
		balance2After, _ := common.GetAccountBalance(ctx, db, 2)

		t.AssertEQ(balance1After, balance1Before)
		t.AssertEQ(balance2After, balance2Before)

		t.Logf("回滚测试结束: 用户1=%.2f, 用户2=%.2f (余额未变)", balance1After, balance2After)
	})
}

// TestSeataXA_BasicTransfer XA模式基础转账测试
func TestSeataXA_BasicTransfer(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test in short mode")
	}

	gtest.C(t, func(t *gtest.T) {
		ctx := context.Background()
		db := common.SetupSeataDB(t.T, "XA")

		err := common.ResetAccountBalances(ctx, db)
		if err != nil {
			t.Fatalf("重置账户余额失败: %v", err)
		}

		balance1Before, _ := common.GetAccountBalance(ctx, db, 1)
		balance2Before, _ := common.GetAccountBalance(ctx, db, 2)

		t.Logf("XA模式转账前: 用户1=%.2f, 用户2=%.2f", balance1Before, balance2Before)

		err = tm.WithGlobalTx(ctx, &tm.GtxConfig{
			Name:    "xa-basic-transfer",
			Timeout: 30 * time.Second,
		}, func(ctx context.Context) error {
			// 扣款
			_, err := db.Model("accounts").
				Where("id", 1).
				Data(gdb.Map{
					"balance": gdb.Raw("balance - ?", 300.00),
				}).Update()
			if err != nil {
				return err
			}

			// 加款
			_, err = db.Model("accounts").
				Where("id", 2).
				Data(gdb.Map{
					"balance": gdb.Raw("balance + ?", 300.00),
				}).Update()
			return err
		})

		t.AssertNil(err)

		balance1After, _ := common.GetAccountBalance(ctx, db, 1)
		balance2After, _ := common.GetAccountBalance(ctx, db, 2)

		t.AssertEQ(balance1After, 9700.00)
		t.AssertEQ(balance2After, 5300.00)

		t.Logf("XA模式转账后: 用户1=%.2f, 用户2=%.2f", balance1After, balance2After)
	})
}