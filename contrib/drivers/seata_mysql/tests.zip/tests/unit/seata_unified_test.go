// Copyright GoFrame Author(https://goframe.org). All Rights Reserved.
//
// This Source Code Form is subject to the terms of the MIT License.
// If a copy of the MIT was not distributed with this file,
// You can obtain one at https://github.com/gogf/gf.

package unit

import (
	"context"
	"testing"
	"time"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame"
	"github.com/gogf/gf/v2/os/gctx"
	"github.com/gogf/gf/v2/test/gtest"
	"github.com/seata/seata-go/pkg/datasource/sql/types"
	"github.com/seata/seata-go/pkg/protocol/branch"
	"github.com/seata/seata-go/pkg/rm"
	"github.com/stretchr/testify/assert"

	seataMysql "github.com/gogf/gf/contrib/drivers/seata_mysql"
)

// Test_Config 测试配置功能
func Test_Config(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		config := seataMysql.DefaultConfig()
		t.AssertNE(config, nil)
		t.AssertEQ(config.ApplicationID, "gf-app")
		t.AssertEQ(config.TxServiceGroup, "default_tx_group")
		t.AssertEQ(config.Mode, "AT")
		t.AssertEQ(config.AT.UndoLogTable, "undo_log")
	})
}

// Test_Driver_Basic 测试基础驱动功能
func Test_Driver_Basic(t *testing.T) {
	ctx := gctx.New()
	
	assert.NotPanics(t, func() {
		seataMysql.Init()
	})

	config := gdb.ConfigNode{
		Type:     "mysql",
		Host:     "127.0.0.1",
		Port:     "3306",
		User:     "root",
		Pass:     "123456",
		Database: "test_seata",
	}

	assert.NotPanics(t, func() {
		seataMysql.NewDriverAT(seataMysql.DefaultConfig())
	})

	assert.NotPanics(t, func() {
		seataMysql.NewDriverXA(seataMysql.DefaultConfig())
	})
}

// Test_AsyncWorker 测试异步工作器
func Test_AsyncWorker(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		worker := seataMysql.NewAsyncWorker(nil, seataMysql.DefaultAsyncWorkerConfig())

		worker.Start()
		t.Assert(worker.IsRunning(), true)

		worker.Stop()
		t.Assert(worker.IsRunning(), false)

		worker.Stop()
	})
}

// Test_AsyncWorker_BranchCommit 测试分支提交
func Test_AsyncWorker_BranchCommit(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		config := seataMysql.DefaultAsyncWorkerConfig()
		config.WorkerPoolSize = 2
		config.QueueSize = 10

		worker := seataMysql.NewAsyncWorker(nil, config)
		worker.Start()
		defer worker.Stop()

		for i := 0; i < 5; i++ {
			err := worker.BranchCommit(rm.BranchResource{
				BranchType: branch.BranchTypeAT,
				Xid:         "test-xid",
				BranchID:    int64(i + 1),
			})
			t.AssertNil(err)
		}
	})
}

// Test_ImageGeneration 测试镜像生成功能
func Test_ImageGeneration(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		beforeImage := &seataMysql.TableRecords{
			TableName: "users",
			Rows: []seataMysql.Row{
				{
					Fields: []seataMysql.Field{
						{Name: "id", KeyType: seataMysql.KeyTypePrimaryKey, Type: 4, Value: 1},
						{Name: "balance", KeyType: seataMysql.KeyTypeCommon, Type: 3, Value: 1000},
					},
				},
			},
		}

		afterImage := &seataMysql.TableRecords{
			TableName: "users",
			Rows: []seataMysql.Row{
				{
					Fields: []seataMysql.Field{
						{Name: "id", KeyType: seataMysql.KeyTypePrimaryKey, Type: 4, Value: 1},
						{Name: "balance", KeyType: seataMysql.KeyTypeCommon, Type: 3, Value: 900},
					},
				},
			},
		}

		pkValues := beforeImage.ExtractPrimaryKeyValues()
		t.Assert(len(pkValues), 1)
		t.Assert(pkValues[0], int64(1))

		primaryKey := beforeImage.GetPrimaryKey()
		t.AssertEQ(primaryKey, "id")
	})
}

// Test_Fallback 测试降级机制
func Test_Fallback(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		fallback := seataMysql.NewFallback(seataMysql.DefaultFallbackConfig())
		
		err := fallback.Execute(func() error {
			return nil
		})
		t.AssertNil(err)
	})
}

// Test_Retry 测试重试机制
func Test_Retry(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		retry := seataMysql.NewRetry(seataMysql.DefaultRetryConfig())
		
		err := retry.Do(func() error {
			return nil
		})
		t.AssertNil(err)
	})
}

// Test_Context 测试事务上下文
func Test_Context(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		ctx := context.Background()
		txCtx := seataMysql.NewTransactionContext(ctx, "test-xid")
		
		t.AssertNE(txCtx, nil)
		t.AssertEQ(txCtx.GetXID(), "test-xid")
	})
}

// Test_Metrics 测试指标收集
func Test_Metrics(t *testing.T) {
	gtest.C(t, func(t *gtest.T) {
		metrics := seataMysql.NewMetrics(seataMysql.DefaultMetricsConfig())
		
		t.AssertNE(metrics, nil)
		
		metrics.IncrementCommitCount()
		metrics.IncrementRollbackCount()
		
		t.AssertGT(metrics.GetCommitCount(), int64(0))
	})
}